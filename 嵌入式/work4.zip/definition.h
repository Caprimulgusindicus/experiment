
#define MODE_INIT			0
#define MODE_MOST_RIGHT		1
#define MODE_MOST_LEFT		2
#define MODE_RIGHT_TO_LEFT	3
#define MODE_LEFT_TO_RIGHT	4
 



