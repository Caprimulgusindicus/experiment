


void disp(char x,int location);

