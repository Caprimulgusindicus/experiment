#include <stdio.h>
#include <LM3Sxxxx.H>
#include <hw_ints.h>
#include <hw_memmap.h>
#include <hw_types.h>
#include <gpio.h>
#include <interrupt.h>
#include <sysctl.h>
#include "rit128x96x4.h"
#include "utility.h"
#include "definition.h"
#include <string.h>
unsigned char x1[] = 
{  
	0x00,0x00, 
	0xff,0xff, 
	0xff,0xff, 
	0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff, 
	0xff,0xff, 
	0xff,0xff,
	0x00,0x00,
}; 

unsigned char x2[] = 
{
  	 0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff, 
} ;


unsigned char x3[] = 
{
  	 0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff, 
}  ;

   unsigned char x4[] = 
{
  	 0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff, 
}	  ;

   unsigned char x5[] = 
{
  	 
	0x00,0x00, 
	0xff,0xff, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00,	
}	;

      unsigned char x6[] = 
{
  	 
	0x00,0x00, 
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00, 
	0xff,0xff,
	0x00,0x00, 
	0x00,0x00,	
}	  ;
   unsigned char x7[] = 
{
  	 
	0x00,0x00,  
	0x00,0x00,
	0x00,0x00, 
	0xff,0xff,
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0xff,0xff,
	0x00,0x00, 
	0x00,0x00, 
	0x00,0x00,	
}	 ;
   unsigned char x8[] = 
{
  	 
	0x00,0x00,  
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0xff,0xff,
	0x00,0x00,
	0xff,0xff, 
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00, 
	0x00,0x00,	
}	  ;
   unsigned char x9[] = 
{
  	 
	0x00,0x00,  
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00,
	0x00,0x00,
	0xff,0xff,
	0x00,0x00,
	0x00,0x00,
	0x00,0x00, 
	0x00,0x00, 
	0x00,0x00,	
}		 ;
int flagmenu=1;
int j,k,delaytime;char buf1[2];char buf2[2];char buf3[2];
char oledkey[2];
char buf[2];
char digits[8];
int i=0;
int countf=0;
int Event_key=0;
int Event=0;
int count=0;
unsigned char ucValue=0x00;
int m,s,ms=0;
int counta=0;
int counte=0;
char change;
int flag=1;//zhengxiang
char ccc[100];
int puchr=0;
int countb=0;

void SysTick_Handler(void) 
{
	Event = 1;
}




void GPIO_PORT_D_ISR(void)
{
unsigned char ucKey;
unsigned long ulStatus;
ulStatus = GPIOPinIntStatus(GPIO_PORTD_BASE, true);
GPIOPinIntClear(GPIO_PORTD_BASE, ulStatus);
if(ulStatus & GPIO_PIN_7)
{
ucKey = GPIOPinRead(GPIO_PORTC_BASE, GPIO_PIN_4);
ucKey = ucKey>>1;
ucValue = ucValue + ucKey;
ucValue = ucValue<<1;
i++;
if(i==4)
{
Event_key=1;  
i=0;
oledkey[1]='\0';
if((ucValue>>4)<10)
oledkey[0] = (ucValue>>4) + 48;
else
oledkey[0] = (ucValue>>4) - 10 + 'A';
}
}
}

void init()//����ʹ��
{
RIT128x96x4Init(1000000);
	RIT128x96x4Clear();   
SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN |SYSCTL_XTAL_8MHZ);
SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
	SYSCTL_XTAL_8MHZ);
/*ʹ������ GPIO*/
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
/*���� GPIO �˿�Ϊ���*/

GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6);
GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7);
GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6);
/*���� GPIO Ϊ����*/
GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_7);
GPIOPinTypeGPIOInput(GPIO_PORTC_BASE, GPIO_PIN_4);
/*ʹ���ж�*/
IntEnable(INT_GPIOD);
IntMasterEnable();
GPIOPinIntEnable(GPIO_PORTD_BASE, GPIO_PIN_7);
GPIOIntTypeSet(GPIO_PORTD_BASE, GPIO_PIN_7, GPIO_RISING_EDGE);

/*��ʱ����ʼ��*/


//ʱ���жϿ���

	SysTickIntDisable();
	SysTickDisable();
	
	SysTickEnable();
	SysTickIntEnable();
	SysTickPeriodSet(SysCtlClockGet() / 100);//x Ϊ����Ĳ��������Ƽ���Ƶ�ʣ�ֵԽ��Ƶ

}


void menu()
{
	sprintf(buf1,"%3i",m);
		RIT128x96x4StringDraw(buf1, 30, 45, 8);
		RIT128x96x4StringDraw(":", 49, 45, 8);
		sprintf(buf2,"%3i",s);
		RIT128x96x4StringDraw(buf2, 51, 45, 8);
		RIT128x96x4StringDraw(":", 69, 45, 8);
		sprintf(buf3,"%3i",ms);
		RIT128x96x4StringDraw(buf3, 74, 45, 8);
		sprintf(buf1,"%2i",m);	 	sprintf(buf2,"%2i",s);	   	sprintf(buf3,"%2i",ms);
	 if(ms<10) digits[2]='0'; 
	 else   digits[2]=buf3[0];
	digits[1]=buf3[1];

	if(s<10) digits[4]='0'; 
	 else digits[4]=buf2[0];
	digits[3]=buf2[1];

	if(m<10) digits[6]='0'; 
	 else digits[6]=buf1[0];
	digits[5]=buf1[1];
	

	for(j=1;j<7;j++)
 	{
 	disp(digits[j],j);
	 for(k=0;k<8000;k++) ; //�����ʵ����ӳ٣�������ʾ������ַ��غ���

	 }

		//if(count>=50)
	//		sprintf(buf, "%3i", count-50);
	//	else 
	//		sprintf(buf, "%3i", count);
	//		RIT128x96x4StringDraw(buf, 50, 45, 8);
			if(count==100)	RIT128x96x4Clear();
		if(count>=0&&count<100){
	
		RIT128x96x4StringDraw("   please choose ", 10, 25, 15); 
		RIT128x96x4StringDraw("     a function   ", 10, 35, 15);  
		RIT128x96x4StringDraw("<A> Pause/Continue",10, 55, 15);  
		RIT128x96x4StringDraw("<B> Set Time", 35, 65, 15);   
		RIT128x96x4StringDraw("<C> Reset", 35, 75, 15);  }
		   if(count==200) 	RIT128x96x4Clear();
		if(count>=100&&count<=200)	 {
		RIT128x96x4StringDraw("   please choose ", 10, 25, 15); 
		RIT128x96x4StringDraw("     a function   ", 10, 35, 15);   
		RIT128x96x4StringDraw("<D> Reverse", 35, 55, 15);  
		RIT128x96x4StringDraw("<E> 'A+B'", 35, 65, 15);
		RIT128x96x4StringDraw("<F> Service", 35, 75, 15);
	   }
	 
	
}

void lalala()
{
   	if(change=='A')
	{
	counta++;
	if(counta%2==0)
	{SysTickEnable();
	SysTickIntEnable();}
	else{
	SysTickIntDisable();
	SysTickDisable();  
	}
   }

if(change=='B')	   
	{
	countb++;
	if(countb%2==0) 
	{
	flagmenu=1;
	RIT128x96x4Clear();
	SysTickEnable();
	SysTickIntEnable();
	menu();}
	else 
	{
		
		SysTickIntDisable();
		SysTickDisable();  	
		flagmenu=0;
		RIT128x96x4Clear();
		RIT128x96x4StringDraw("<Type>Set Time:", 10, 25, 15); 
		RIT128x96x4StringDraw("<B>   return  ", 10, 65, 15); 
		//  	RIT128x96x4StringDraw(ccc+1, 10, 45, 15); 
		 
		m=23;s=33;ms=33;
		 
	}
	}


	if(change=='C') {ms=0;s=0;m=0;}
	if(change=='D')	flag=-flag;

	if(change=='E')	   
	{
	counte++;
	if(counte%2==0) 
	{
	flagmenu=1;
	RIT128x96x4Clear();
	SysTickEnable();
	SysTickIntEnable();
	menu();}
	else 
	{
		
		SysTickIntDisable();
		SysTickDisable();  	
		flagmenu=0;
		RIT128x96x4Clear();
		RIT128x96x4StringDraw("<A+B> Show heart", 10, 25, 15); 
		RIT128x96x4StringDraw("<E>   return  ", 10, 35, 15); 
		  	 
	}
	}
	if(change=='F')	   
	{
	   {
	countf++;
	if(countf%2==0) 
	{
	memset(ccc,0,sizeof(ccc));
	flagmenu=1;
	RIT128x96x4Clear();
	SysTickEnable();
	SysTickIntEnable();
	menu();}
	else 
	{
		
		SysTickIntDisable();
		SysTickDisable();  	
		flagmenu=0;
		RIT128x96x4Clear();
		RIT128x96x4StringDraw("Read numbers:", 10, 25, 15); 
		RIT128x96x4StringDraw("<F>   return  ", 10, 35, 15); 
		  	 
	}
	}
}
}

int main()
{	 
	
	init();
	 
   while(1)	{
	if(Event)
{
	  Event=0;
		if(count>200) 
		count=0;
		else count ++;
	   if(flag==1){
		if(ms>99)
		{ms=0;s++;} else ms++;
		if(s>59)
		{s=0;m++;} //else s++;
		if(m>60){m=0;} //else m++;
		}
		if(flag==-1)
		{
		if(ms>0) ms--;
			else {s--;ms=60;}
		if(s==0) 
			 {m--;s=60;}
		if(m<0) {m=60;s=60;ms=99;} 
		}
		if(flagmenu)
			menu();
	
		
}
if(Event_key)
{

	Event_key=0;
	change=oledkey[0];
	ccc[puchr]=change;
	puchr++;
	if(counte%2!=0&&ccc[puchr-2]=='A'&&ccc[puchr-1]=='B')
	{
	//RIT128x96x4StringDraw(ccc, 10, 45, 15); 
			/*heart*/
	    RIT128x96x4ImageDraw(x1, 40, 55, 44, 1); 
		 RIT128x96x4ImageDraw(x2, 40, 58, 44, 1); 
 		RIT128x96x4ImageDraw(x3, 40, 61, 44, 1); 
		 RIT128x96x4ImageDraw(x4, 40, 64, 44, 1);
		RIT128x96x4ImageDraw(x5, 40, 67, 44, 1); 
		RIT128x96x4ImageDraw(x6, 40, 70, 44, 1); 
		RIT128x96x4ImageDraw(x7, 40, 73, 44, 1); 
		  RIT128x96x4ImageDraw(x8, 40, 76, 44, 1); 
		 RIT128x96x4ImageDraw(x9, 40, 79, 44, 1); 
		 }
	else if(countf%2!=0&&(ccc[puchr-1]!='2'||ccc[puchr-1]!='3'))
	{		
	RIT128x96x4Clear();
		 RIT128x96x4StringDraw(ccc+1, 15, 45, 15); 
		 RIT128x96x4StringDraw("input numbers       ", 15, 55, 15);   
		 //memset(ccc,0,sizeof(ccc));
		 
	}	
		else if(countf%2!=0&&ccc[puchr-1]=='2')
	{
			  RIT128x96x4Clear();
		 //RIT128x96x4StringDraw(ccc+1, 15, 45, 15); 
		 RIT128x96x4StringDraw("see some words     ", 15, 55, 15); 
		 
	}  
			else if(countf%2!=0&&ccc[puchr-1]=='3')
	{
				RIT128x96x4Clear();
		 //RIT128x96x4StringDraw(ccc+1, 15, 45, 15); 
		 RIT128x96x4StringDraw("to a next function ", 15, 55, 15); 
		 
	}
	else lalala();
}
}	 
//	menu();

}